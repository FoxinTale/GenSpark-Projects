import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from 'src/app/api/api.service';
import { UserModel } from 'src/app/Models/user.model';

@Component({
  selector: 'app-create-journal',
  templateUrl: './create-journal.component.html',
  styleUrls: ['./create-journal.component.css']
})
export class CreateJournalComponent implements OnInit{
  formValue !: FormGroup;
  user: UserModel = new UserModel();
  userDataArray !: any;
  
  constructor(private formBuilder: FormBuilder, private api : ApiService) {}

  ngOnInit(): void{
    this.formValue = this.formBuilder.group({
      userName: [''],
      userPassword: [''],
      userEmail: [''],
      userIsAdmin: false
    })
    this.getUserData();
  }

  getUserData(){
    this.api.getUser().subscribe(result=>{
      this.userDataArray = result;
    })
  }

  postUserData(){
    this.user.userName = this.formValue.value.userName;
    this.user.userPassword = this.formValue.value.userPassword;
    this.user.userEmail = this.formValue.value.userEmail;

    this.api.postUser(this.user).subscribe(result=>{
      console.log(result);
      this.formValue.reset();
    },
    err=>{
      alert("Great Googly-Moogly it's all gone to sh*t!.");
    })
  }
  

  deleteUserData(row:any){
    this.api.deleteUser(row.id).subscribe(result =>{
      window.location.reload();
      alert("Deletion successful.");
    })
  }
}
