import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from 'src/app/api/api.service';
import { characterModel } from 'src/app/Models/character.model';

@Component({
  selector: 'app-create-character',
  templateUrl: './create-character.component.html',
  styleUrls: ['./create-character.component.css']
})


export class CreateCharacterComponent implements OnInit{
  formValue !: FormGroup;
  character: characterModel = new characterModel();
  charDataArray !: any;

  constructor(private formBuilder: FormBuilder, private api : ApiService) {}
  characterID: number = 0;

  ngOnInit(): void{
    this.formValue = this.formBuilder.group({
      charFullName: [''],
      charShortName: [''],
      charShortDesc: [''],
      charAge: [''],
      charGender: [''],
      charSpecies: ['']
    })
    this.getCharacterData();
  }


  getCharacterData(){
    this.api.getCharacter().subscribe(result=>{
      this.charDataArray = result
    })  
  }

  addCharacter(character: CharacterData){
    const headers = { 'content-type': 'application/json'}
    const body = JSON.stringify(character);
    console.log(body);
  }

  editCharacterInfo(char:any){
    this.characterID = char.id;
    this.api.getCharacterByID(char.id).subscribe(result =>{
      console.log(result);
      document.getElementById('displayInfo')!.style.display = "block";
      
      (<HTMLInputElement>document.getElementById("charname")).value = char.charFullName;
      (<HTMLInputElement>document.getElementById("charalias")).value = char.charShortName;
      (<HTMLInputElement>document.getElementById("charshortdesc")).value = char.charShortDesc;
      (<HTMLInputElement>document.getElementById("charage")).value = char.charAge;
      (<HTMLInputElement>document.getElementById("chargender")).value = char.charGender;
      (<HTMLInputElement>document.getElementById("charspecies")).value = char.charSpecies;
      
    })
  }

  postCharacterData(){
    this.character.charFullName = this.formValue.value.charFullName;
    this.character.charShortName = this.formValue.value.charShortName;
    this.character.charShortDesc = this.formValue.value.charShortDesc;
    this.character.charAge = this.formValue.value.charAge;
    this.character.charGender = this.formValue.value.charGender;
    this.character.charSpecies = this.formValue.value.charSpecies;

    this.api.postCharacter(this.character).subscribe(result=>{
      console.log(result);
      this.formValue.reset();
    },
    err=>{
      alert("Great Googly-Moogly it's all gone to sh*t!.");
    })
  }

  updateCharacterData(){
    this.character.charID = this.characterID
    this.character.charFullName = (<HTMLInputElement>document.getElementById("charname")).value;
    this.character.charShortName = (<HTMLInputElement>document.getElementById("charalias")).value;
    this.character.charShortDesc = (<HTMLInputElement>document.getElementById("charshortdesc")).value;
    this.character.charAge = (<HTMLInputElement>document.getElementById("charage")).value;
    this.character.charGender = (<HTMLInputElement>document.getElementById("chargender")).value;
    this.character.charSpecies = (<HTMLInputElement>document.getElementById("charspecies")).value;

    this.api.updateCharacter(this.character).subscribe(result=>{
      console.log(result);
      this.formValue.reset();
    },
    err=>{
      alert("Great Googly-Moogly it's all gone to sh*t!.");
    })
  }

  deleteCharacter(row:any){
    this.api.deleteCharacter(row.id).subscribe(result=>{
      window.location.reload();
      alert("Delete successful.");
    })
  }
  
}
