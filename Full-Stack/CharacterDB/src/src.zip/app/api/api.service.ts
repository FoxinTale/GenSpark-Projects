import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http : HttpClient) { }

  postCharacter(data:any) {
    return this.http.post<any> ("http://localhost:3000/character", data).pipe(map((result:any)=>
    {
      return result;
    }))
  }

  updateCharacter(data: any) {
    return this.http.put<any> ("http://localhost:3000/character/" + data.charID, data).pipe(map((result:any)=>
    {
      return result;
    }))
  }

  getCharacter() {
    return this.http.get<any>("http://localhost:3000/character").pipe(map((result:any)=> {
      return result;
    }))
  }

  getCharacterByID(charID: number){
    return this.http.get<any>("http://localhost:3000/character/" + charID).pipe(map((result:any)=> {
      return result;
    }))
  }
  
  deleteCharacter(charID : number) {
    return this.http.delete<any>("http://localhost:3000/character/" + charID).pipe(map((result:any)=> {
      return result;
    }))
  }


  
  postUser(data:any) {
    return this.http.post<any> ("http://localhost:3000/user", data).pipe(map((result:any)=>
    {
      return result;
    }))
  }

  getUser() {
    return this.http.get<any>("http://localhost:3000/user").pipe(map((result:any)=> {
      return result;
    }))
  }

  getUserByName(){
    
  }
  
  deleteUser(userID : number) {
    return this.http.delete<any>("http://localhost:3000/user/" + userID).pipe(map((result:any)=> {
      return result;
    }))
  }

}
