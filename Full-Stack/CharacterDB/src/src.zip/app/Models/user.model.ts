export class UserModel{
    userID: number = 0;
    userName: string = '';
    userPassword: string = '';
    userEmail: string = '';
    userIsAdmin: boolean = false;
}