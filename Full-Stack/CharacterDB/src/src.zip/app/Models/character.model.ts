export class characterModel{
    charID: number = 0;
    charFullName: string = '';
    charShortName: string = '';
    charShortDesc: string = '';
    charAge: string = '';
    charGender: string = '';
    charSpecies: string= '';
}