export class LoginModel{
    userName: string = '';
    userPassword: string = '';
}